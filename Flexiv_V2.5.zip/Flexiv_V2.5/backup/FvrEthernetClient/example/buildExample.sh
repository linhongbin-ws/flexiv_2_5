g++ -o ExampleClient main.cpp -I../include/ -I./Eigen/ -pthread -L ../lib/ -lFvrEthernetClient -lanl
